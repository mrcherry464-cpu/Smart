SMARK Custom Keyboard for iPhone
=================================

This is the starter Xcode project source for an iOS custom keyboard extension.

WHAT IT DOES
- QWERTY keyboard with letters, space, delete and return
- Draggable blue circle marker
- When a key is pressed, the circle animates down onto that key
- Works in apps that allow third-party keyboards, after the keyboard is enabled

IMPORTANT
This download is source code, not an already-signed iPhone app.
Apple requires the project to be built and signed with Xcode on a Mac using your Apple ID.
I cannot sign or install an iOS keyboard extension directly from this chat.

BUILD IN XCODE
1. On a Mac, install Xcode.
2. Create a new iOS App project named SMARK (Interface: SwiftUI, Language: Swift).
3. Add a new target: iOS > Custom Keyboard Extension. Name it SMARKKeyboard.
4. Replace the generated SMARK app source with SMARK/SMARKApp.swift and SMARK/ContentView.swift.
5. Replace the generated keyboard target's KeyboardViewController.swift with SMARKKeyboard/KeyboardViewController.swift.
6. In the keyboard target's Info.plist, set:
   NSExtension > NSExtensionAttributes > RequestsOpenAccess = NO
   NSExtension > NSExtensionPointIdentifier = com.apple.keyboard-service
   NSExtension > NSExtensionPrincipalClass = $(PRODUCT_MODULE_NAME).KeyboardViewController
7. Set the keyboard target's deployment target to iOS 15 or later.
8. Select your Apple Developer Team for both targets, then Build and Run the SMARK app on your iPhone.
9. On iPhone: Settings > General > Keyboard > Keyboards > Add New Keyboard > SMARK.
10. In any text field, hold the globe key and choose SMARK.

NOTE ABOUT IOS
iOS custom keyboards cannot appear in every secure/password field or some protected text fields.
The keyboard inserts normal text; it cannot control other apps or simulate system-wide touches.

PROJECT FILES
- SMARK/SMARKApp.swift: host app entry point
- SMARK/ContentView.swift: setup instructions in the app
- SMARKKeyboard/KeyboardViewController.swift: keyboard UI and circle animation
